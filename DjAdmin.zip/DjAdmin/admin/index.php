<script src="../jquery.js"></script>

<?php include '../connection.php'; ?>
<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
    <meta name="author" content="AdminKit">
    <meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="shortcut icon" href="../img/icons/icon-48x48.png" />

    <link rel="canonical" href="https://demo-basic.adminkit.io/pages-sign-in.html" />

    <title>Sign In | AdminKit Demo</title>

    <link href="../css/app.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<style>
    .display_bloack {
        display: block;
    }

    .alert_danger {
        border: 1px solid #eb7d7d;
        text-align: center;
        background-color: #eb7d7d;
        margin-top: 0px;
        display: none;

    }

    .alert_sucess {
        border: 1px solid #3af33f;
        text-align: center;
        background-color: #3af33f;
        margin-top: 0px;
        display: none;


    }

    .danger h1,
    h2 {
        color: white;
    }

    .cross {
        cursor: pointer;
        float: right;
        justify-content: center;


    }
</style>

<body>
    <div class="alert_danger">

        <div class="danger">

            <h1>
                <h2 id="sethtml">Please Enter Your name</h2> <span><svg class="cross" id="cross" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x align-middle me-2">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg></span>
            </h1>
        </div>

    </div>
    <div class="alert_sucess">

        <div class="danger">

            <h1 id="">Login Sucessfull<span><svg class="cross" id="cross_sucess" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x align-middle me-2">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg></span></h1>
        </div>

    </div>
    <main class="d-flex w-100">
        <div class="container d-flex flex-column">
            <div class="row vh-100">
                <div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
                    <div class="d-table-cell align-middle">

                        <div class="text-center mt-4">
                            <h1 class="h2">Welcome back</h1>
                            <p class="lead">
                                Sign in to your account to continue
                                <a href="signup.php">
                                    <p> Don't Have Account Signup Now </p>
                                </a>
                            </p>

                        </div>

                        <?php





                        ?>


                        <?php
                        if (isset($_POST['login'])) {


                            $login_query = "SELECT * FROM `signuplogin` WHERE  `emailid`='$_POST[email]' AND `password`='$_POST[password]'";
                            $query_fire = $conn->query($login_query);
                            if ($query_fire) {

                                if (mysqli_num_rows($query_fire) > 0) {
                                    echo "<script>
                                    $(document).ready(function(){
                                   
                                       $('#sethtml').html('<h2>Login Sucessfull</h2>')
                
                                   $('.alert_sucess').show(function(){
                                      $('#cross').click(function(){
                                            $('.alert_danger').hide(500);
                                            
                                        
                                        
                                        });});});
                                        
                                        function pageRedirect() {
                                            window.location.replace('../index.php');
                                        }      
                                        setTimeout('pageRedirect()', 3000);
                                        
                                        
                                        
                                        </script>";

                                    $data_fetch = mysqli_fetch_assoc($query_fire);
                                    $_SESSION["username"] = $data_fetch["name"];
                                } else {
                                    echo "<script>
                                    $(document).ready(function(){
                                   
                                       $('#sethtml').html('<h2>Incorrect Details</h2>')
                
                                   $('.alert_danger').show(function(){
                                      $('#cross').click(function(){
                                            $('.alert_danger').hide(500);});});});</script>";
                                }
                            }
                        }






                        ?>

                        <div class="card">
                            <div class="card-body">
                                <div class="m-sm-4">
                                    <div class="text-center">
                                        <img src="../img/avatars/avtar.png" alt="Charles Hall" class="img-fluid rounded-circle" width="132" height="132" />
                                    </div>
                                    <form action="#" method="POST">
                                        <div class="mb-3">
                                            <label class="form-label">Email</label>
                                            <input class="form-control form-control-lg" type="email" name="email" placeholder="Enter your email" />
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Password</label>
                                            <input class="form-control form-control-lg" type="password" name="password" placeholder="Enter your password" />
                                            <small>
                                                <a href="#">Forgot password?</a>
                                            </small>

                                        </div>
                                        <div>
                                            <label class="form-check">
                                                <input class="form-check-input" type="checkbox" value="remember-me" name="remember-me" checked>
                                                <span class="form-check-label">
                                                    Remember me next time
                                                </span>
                                            </label>
                                        </div>
                                        <div class="text-center mt-3">

                                            <button type="submit" name="login" class="btn btn-lg btn-primary">Sign in</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="js/app.js"></script>

</body>

</html>